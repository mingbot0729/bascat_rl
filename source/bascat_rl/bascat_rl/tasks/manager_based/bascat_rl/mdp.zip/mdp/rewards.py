# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Common functions that can be used to define rewards for the learning environment.

The functions can be passed to the :class:`isaaclab.managers.RewardTermCfg` object to
specify the reward function and its parameters.
"""

from __future__ import annotations

import torch
from typing import TYPE_CHECKING

from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import ContactSensor
from isaaclab.utils.math import quat_apply_inverse, yaw_quat

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


def feet_air_time(
    env: ManagerBasedRLEnv, command_name: str, sensor_cfg: SceneEntityCfg, threshold: float
) -> torch.Tensor:
    """Reward long steps taken by the feet using L2-kernel.

    This function rewards the agent for taking steps that are longer than a threshold. This helps ensure
    that the robot lifts its feet off the ground and takes steps. The reward is computed as the sum of
    the time for which the feet are in the air.

    If the commands are small (i.e. the agent is not supposed to take a step), then the reward is zero.
    """
    # extract the used quantities (to enable type-hinting)
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    # compute the reward
    first_contact = contact_sensor.compute_first_contact(env.step_dt)[:, sensor_cfg.body_ids]
    last_air_time = contact_sensor.data.last_air_time[:, sensor_cfg.body_ids]
    reward = torch.sum((last_air_time - threshold) * first_contact, dim=1)
    # no reward for zero command
    reward *= torch.norm(env.command_manager.get_command(command_name)[:, :2], dim=1) > 0.1
    return reward


def feet_air_time_positive_biped(env, command_name: str, threshold: float, sensor_cfg: SceneEntityCfg) -> torch.Tensor:
    """Reward long steps taken by the feet for bipeds.

    This function rewards the agent for taking steps up to a specified threshold and also keep one foot at
    a time in the air.

    If the commands are small (i.e. the agent is not supposed to take a step), then the reward is zero.
    """
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    # compute the reward
    air_time = contact_sensor.data.current_air_time[:, sensor_cfg.body_ids]
    contact_time = contact_sensor.data.current_contact_time[:, sensor_cfg.body_ids]
    in_contact = contact_time > 0.0
    in_mode_time = torch.where(in_contact, contact_time, air_time)
    single_stance = torch.sum(in_contact.int(), dim=1) == 1
    reward = torch.min(torch.where(single_stance.unsqueeze(-1), in_mode_time, 0.0), dim=1)[0]
    reward = torch.clamp(reward, max=threshold)
    # no reward for zero command
    reward *= torch.norm(env.command_manager.get_command(command_name)[:, :2], dim=1) > 0.1
    return reward


def feet_air_time_positive_biped_with_standing(
    env: ManagerBasedRLEnv,
    command_name: str,
    threshold: float,
    sensor_cfg: SceneEntityCfg,
    min_standing_reward: float = 0.25,
    cmd_threshold: float = 0.1,
) -> torch.Tensor:
    """Biped reward with minimum when vel command is zero: reward standing still in single-stance.
    When cmd > cmd_threshold: same as feet_air_time_positive_biped (reward up to threshold).
    When cmd <= cmd_threshold: give min_standing_reward if single_stance (one foot in contact), else 0.
    """
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    air_time = contact_sensor.data.current_air_time[:, sensor_cfg.body_ids]
    contact_time = contact_sensor.data.current_contact_time[:, sensor_cfg.body_ids]
    in_contact = contact_time > 0.0
    in_mode_time = torch.where(in_contact, contact_time, air_time)
    single_stance = torch.sum(in_contact.int(), dim=1) == 1
    cmd_norm = torch.norm(env.command_manager.get_command(command_name)[:, :2], dim=1)

    # Moving: same as original (reward clamped to threshold, zero if cmd small)
    reward_moving = torch.min(torch.where(single_stance.unsqueeze(-1), in_mode_time, 0.0), dim=1)[0]
    reward_moving = torch.clamp(reward_moving, max=threshold)
    reward_moving *= (cmd_norm > cmd_threshold).float()

    # Standing (cmd <= threshold): minimum reward if biped single-stance
    reward_standing = min_standing_reward * single_stance.float() * (cmd_norm <= cmd_threshold).float()

    return reward_moving + reward_standing


def gait_alternating_phase(
    env: ManagerBasedRLEnv,
    sensor_cfg: SceneEntityCfg,
    threshold: float = 0.4,
    phase_time_bonus_max: float = 0.2,
) -> torch.Tensor:
    """Reward proper bipedal gait: exactly one foot in contact (alternating phase).
    When both legs are at different phase (one touching ground, one in the air), give reward.
    Optionally scale by how long they have been in that phase (phase_time_bonus_max sec cap).
    Expects sensor_cfg to resolve to 2 bodies: [left_lower_leg_link, right_lower_leg_link].
    """
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    contact_time = contact_sensor.data.current_contact_time[:, sensor_cfg.body_ids]
    air_time = contact_sensor.data.current_air_time[:, sensor_cfg.body_ids]
    in_contact = contact_time > 0.0
    # Exactly one foot in contact (alternating stance)
    left_contact = in_contact[:, 0]
    right_contact = in_contact[:, 1]
    alternating = (left_contact & ~right_contact) | (~left_contact & right_contact)
    # Time in current phase: stance foot contact_time, swing foot air_time
    stance_time = torch.where(left_contact, contact_time[:, 0], contact_time[:, 1])
    swing_time = torch.where(left_contact, air_time[:, 1], air_time[:, 0])
    phase_time = torch.min(stance_time, swing_time).clamp(max=phase_time_bonus_max)
    # Base reward for alternating + small bonus for sustained phase
    reward = alternating.float() * (1.0 + phase_time / max(phase_time_bonus_max, 1e-6))
    return reward


def flat_posture_when_biped(
    env: ManagerBasedRLEnv,
    sensor_cfg: SceneEntityCfg,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    roll_scale: float = 4.0,
    pitch_scale: float = 4.0,
) -> torch.Tensor:
    """Reward for keeping the body flat (small roll/pitch). Given whenever posture is flat, regardless of contact."""
    asset = env.scene[asset_cfg.name]
    quat = asset.data.root_quat_w
    w, x, y, z = quat[:, 0], quat[:, 1], quat[:, 2], quat[:, 3]
    roll = torch.atan2(2.0 * (w * x + y * z), 1.0 - 2.0 * (x * x + y * y))
    pitch = torch.asin(torch.clamp(2.0 * (w * y - z * x), -1.0, 1.0))
    return torch.exp(-roll_scale * torch.square(roll) - pitch_scale * torch.square(pitch))


def base_pos_xy_drift_l2(
    env: ManagerBasedRLEnv,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    """Penalize XY position drift from episode start (don't wander away).
    Stores base_pos_xy at reset; returns (pos_xy - pos_xy_reset)^2 summed over x,y per env.
    Use with negative weight.
    """
    asset = env.scene[asset_cfg.name]
    pos_xy = asset.data.root_pos_w[:, :2]

    # Get episode length to detect first step after reset
    episode_length_b = getattr(env, "episode_length_b", None)
    if episode_length_b is None:
        common = getattr(env, "common", None)
        episode_length_b = getattr(common, "episode_length_b", None) if common is not None else None
    if episode_length_b is None:
        just_reset = torch.zeros(env.num_envs, dtype=torch.bool, device=pos_xy.device)
    else:
        just_reset = episode_length_b.squeeze(-1) <= 1

    # Lazy-init buffer for reset position (num_envs, 2)
    key = "_base_pos_xy_reset"
    if not hasattr(env, key):
        setattr(env, key, pos_xy.clone().detach())
    reset_pos = getattr(env, key)
    if reset_pos.shape[0] != pos_xy.shape[0] or reset_pos.device != pos_xy.device:
        setattr(env, key, pos_xy.clone().detach())
        reset_pos = getattr(env, key)
    # Update stored position at episode start
    if just_reset.any():
        mask = just_reset.unsqueeze(-1).expand_as(pos_xy)
        new_reset = reset_pos.clone()
        new_reset[mask] = pos_xy[mask].detach()
        setattr(env, key, new_reset)
        reset_pos = getattr(env, key)

    drift_sq = torch.sum(torch.square(pos_xy - reset_pos), dim=1)
    return drift_sq


def left_right_joint_sym_l2(
    env: ManagerBasedRLEnv,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    """Penalize left/right joint asymmetry. Roll: left + right (mirror). Legs: left - right (equal).
    Expects joint order: left_roll, right_roll, left_upper_leg, right_upper_leg, left_lower_leg, right_lower_leg.
    """
    asset = env.scene[asset_cfg.name]
    joint_pos = asset.data.joint_pos
    names = getattr(asset, "joint_names", None)
    if names is None or len(names) < 6:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    name_to_idx = {n: i for i, n in enumerate(names)}
    idx = [
        name_to_idx.get("left_roll_joint"),
        name_to_idx.get("right_roll_joint"),
        name_to_idx.get("left_upper_leg_joint"),
        name_to_idx.get("right_upper_leg_joint"),
        name_to_idx.get("left_lower_leg_joint"),
        name_to_idx.get("right_lower_leg_joint"),
    ]
    if any(i is None for i in idx):
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    lr, rr, lu, ru, ll, rl = [joint_pos[:, i] for i in idx]
    # Roll: mirror (left = -right) -> (lr + rr)^2; legs: same -> (lu - ru)^2, (ll - rl)^2
    sym_sq = torch.square(lr + rr) + torch.square(lu - ru) + torch.square(ll - rl)
    return sym_sq


def action_sym_l2(env: ManagerBasedRLEnv) -> torch.Tensor:
    """Penalize left/right action asymmetry. Expects action dim 6: [l_roll, r_roll, l_upper, r_upper, l_lower, r_lower]."""
    action_mgr = getattr(env, "action_manager", None)
    if action_mgr is None:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    terms = getattr(action_mgr, "terms", None) or getattr(action_mgr, "_terms", None)
    if terms is None:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    # terms may be dict (name -> term) or list
    term_list = list(terms.values()) if isinstance(terms, dict) else terms
    if not term_list:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    first_term = term_list[0]
    act = getattr(first_term, "processed_actions", None)
    if act is None:
        act = getattr(first_term, "raw_actions", None)
    if act is None or act.shape[-1] < 6:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    a = act[:, :6]
    sym_sq = torch.square(a[:, 0] + a[:, 1]) + torch.square(a[:, 2] - a[:, 3]) + torch.square(a[:, 4] - a[:, 5])
    return sym_sq


def contact_switch_penalty(
    env: ManagerBasedRLEnv,
    sensor_cfg: SceneEntityCfg,
    threshold: float = 0.2,
) -> torch.Tensor:
    """Penalize contact state flips (stops fast micro-stepping / buzzing feet)."""
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    contact_time = contact_sensor.data.current_contact_time[:, sensor_cfg.body_ids]
    in_contact = (contact_time > 0.0).float()

    key = "_contact_switch_prev"
    if not hasattr(env, key):
        setattr(env, key, in_contact.clone().detach())
    prev = getattr(env, key)
    if prev.shape != in_contact.shape or prev.device != in_contact.device:
        setattr(env, key, in_contact.clone().detach())
        prev = getattr(env, key)
    # Penalty = number of feet that changed state (0, 1, or 2)
    switched = (in_contact != prev).float().sum(dim=1)
    setattr(env, key, in_contact.clone().detach())
    return switched


def feet_slide(env, sensor_cfg: SceneEntityCfg, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """Penalize feet sliding.

    This function penalizes the agent for sliding its feet on the ground. The reward is computed as the
    norm of the linear velocity of the feet multiplied by a binary contact sensor. This ensures that the
    agent is penalized only when the feet are in contact with the ground.
    """
    # Penalize feet sliding
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    contacts = contact_sensor.data.net_forces_w_history[:, :, sensor_cfg.body_ids, :].norm(dim=-1).max(dim=1)[0] > 1.0
    asset = env.scene[asset_cfg.name]

    body_vel = asset.data.body_lin_vel_w[:, asset_cfg.body_ids, :2]
    reward = torch.sum(body_vel.norm(dim=-1) * contacts, dim=1)
    return reward


def track_lin_vel_xy_yaw_frame_exp(
    env, std: float, command_name: str, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
) -> torch.Tensor:
    """Reward tracking of linear velocity commands (xy axes) in the gravity aligned robot frame using exponential kernel."""
    # extract the used quantities (to enable type-hinting)
    asset = env.scene[asset_cfg.name]
    vel_yaw = quat_apply_inverse(yaw_quat(asset.data.root_quat_w), asset.data.root_lin_vel_w[:, :3])
    lin_vel_error = torch.sum(
        torch.square(env.command_manager.get_command(command_name)[:, :2] - vel_yaw[:, :2]), dim=1
    )
    return torch.exp(-lin_vel_error / std**2)


def track_ang_vel_z_world_exp(
    env, command_name: str, std: float, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
) -> torch.Tensor:
    """Reward tracking of angular velocity commands (yaw) in world frame using exponential kernel."""
    # extract the used quantities (to enable type-hinting)
    asset = env.scene[asset_cfg.name]
    ang_vel_error = torch.square(env.command_manager.get_command(command_name)[:, 2] - asset.data.root_ang_vel_w[:, 2])
    return torch.exp(-ang_vel_error / std**2)


def base_height_low_penalty(
    env: ManagerBasedRLEnv, target_height: float, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
) -> torch.Tensor:
    """One-sided penalty for base height being too low.
    
    Only penalizes when height is below target, not when above.
    Reward = -max(0, target_height - current_height)^2
    
    This prevents the robot from crouching/kneeling without penalizing standing tall.
    """
    asset = env.scene[asset_cfg.name]
    # Get the base height (z position)
    current_height = asset.data.root_pos_w[:, 2]
    # One-sided penalty: only penalize being too low
    height_deficit = torch.clamp(target_height - current_height, min=0.0)
    return torch.square(height_deficit)


def base_height_target_exp(
    env: ManagerBasedRLEnv,
    target_height: float,
    std: float = 0.05,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    """Reward for base height being close to a target value.
    
    Uses exponential kernel: reward = exp(-((h - target)^2) / (2 * std^2))
    - At target height: reward = 1.0
    - Further from target: reward smoothly decreases toward 0
    
    std controls how sharply the reward falls off (larger std = more tolerance).
    """
    asset = env.scene[asset_cfg.name]
    current_height = asset.data.root_pos_w[:, 2]
    height_error_sq = torch.square(current_height - target_height)
    return torch.exp(-height_error_sq / (2.0 * std**2))


def base_height_high_penalty(
    env: ManagerBasedRLEnv,
    max_height: float,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    """One-sided penalty for base height exceeding max_height.
    
    Only penalizes when height is above max_height.
    Penalty = max(0, current_height - max_height)^2
    Use with negative weight to discourage standing too tall.
    """
    asset = env.scene[asset_cfg.name]
    current_height = asset.data.root_pos_w[:, 2]
    height_excess = torch.clamp(current_height - max_height, min=0.0)
    return torch.square(height_excess)


def alive_posture_bonus(
    env: ManagerBasedRLEnv,
    height_threshold: float = 0.28,
    roll_threshold: float = 0.3,
    pitch_threshold: float = 0.3,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
) -> torch.Tensor:
    """Positive bonus for maintaining good posture.
    
    Returns 1.0 if:
    - Base height > height_threshold
    - |roll| < roll_threshold
    - |pitch| < pitch_threshold
    
    Otherwise returns 0.0.
    This prevents "low-energy crouch" strategies from winning.
    """
    asset = env.scene[asset_cfg.name]
    
    # Get base height
    current_height = asset.data.root_pos_w[:, 2]
    
    # Get roll and pitch from quaternion
    # root_quat_w is (w, x, y, z) quaternion
    quat = asset.data.root_quat_w
    # Extract roll and pitch using quaternion to euler conversion
    # roll = atan2(2*(w*x + y*z), 1 - 2*(x^2 + y^2))
    # pitch = asin(2*(w*y - z*x))
    w, x, y, z = quat[:, 0], quat[:, 1], quat[:, 2], quat[:, 3]
    roll = torch.atan2(2.0 * (w * x + y * z), 1.0 - 2.0 * (x * x + y * y))
    pitch = torch.asin(torch.clamp(2.0 * (w * y - z * x), -1.0, 1.0))
    
    # Check all conditions
    height_ok = current_height > height_threshold
    roll_ok = torch.abs(roll) < roll_threshold
    pitch_ok = torch.abs(pitch) < pitch_threshold
    
    # Return 1.0 if all conditions met, 0.0 otherwise
    upright_bonus = (height_ok & roll_ok & pitch_ok).float()
    return upright_bonus


def foot_slip_penalty(
    env: ManagerBasedRLEnv, 
    sensor_cfg: SceneEntityCfg, 
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    threshold: float = 1.0
) -> torch.Tensor:
    """Penalize feet sliding when in contact with ground.
    
    This penalty helps prevent dragging/sliding behaviors by penalizing
    any foot velocity when the foot is in contact with the ground.
    """
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    # Check if feet are in contact (force > threshold)
    contacts = contact_sensor.data.net_forces_w_history[:, :, sensor_cfg.body_ids, :].norm(dim=-1).max(dim=1)[0] > threshold
    
    # Get foot velocities
    asset = env.scene[asset_cfg.name]
    body_vel = asset.data.body_lin_vel_w[:, asset_cfg.body_ids, :2]  # Only xy velocity
    
    # Penalize velocity when in contact
    reward = torch.sum(body_vel.norm(dim=-1) * contacts, dim=1)
    return reward


def foot_contact_force_penalty(
    env: ManagerBasedRLEnv,
    sensor_cfg: SceneEntityCfg,
    force_threshold: float = 50.0,
) -> torch.Tensor:
    """Penalty for high foot contact force (encourages gentle foot contact).
    Returns sum over feet of max(0, force_magnitude - force_threshold) so only forces above
    the threshold are penalized. Use with negative weight in reward config.
    """
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    # Shape: (num_envs, history, body_ids, 3) -> norm -> (num_envs, history, body_ids)
    forces = contact_sensor.data.net_forces_w_history[:, :, sensor_cfg.body_ids, :].norm(dim=-1)
    # Use current/latest (last step in history) or max over history
    force_mag = forces[:, -1, :]  # (num_envs, num_bodies)
    excess = torch.clamp(force_mag - force_threshold, min=0.0)
    return torch.sum(excess, dim=1)


def amp_reward(
    env: ManagerBasedRLEnv,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    epsilon: float = 1e-6,
) -> torch.Tensor:
    """Reward for fooling the AMP discriminator. Set env.unwrapped.amp_discriminator to the discriminator module.
    If amp_discriminator is None, returns zeros. Reward = -log(1 - D(amp_obs)) so policy is encouraged to look like reference."""
    from .amp_observations import amp_state_ostrich

    unwrapped = getattr(env, "unwrapped", env)
    D = getattr(unwrapped, "amp_discriminator", None)
    if D is None:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
    amp_obs = amp_state_ostrich(env, asset_cfg=asset_cfg)
    with torch.no_grad():
        d_out = D(amp_obs).squeeze(-1).clamp(epsilon, 1.0 - epsilon)
    return -torch.log(1.0 - d_out)


def termination_penalty_scaled(
    env: ManagerBasedRLEnv,
    max_penalty: float = 200.0,
) -> torch.Tensor:
    """Termination penalty that scales with episode length; no penalty on timeout.
    Penalty = -max_penalty * (episode_length / max_episode_steps) only when terminated (not time_out).
    When the episode ends due to time_out, returns 0 (no penalty).
    """
    term_mgr = getattr(env, "termination_manager", None) or getattr(getattr(env, "unwrapped", env), "termination_manager", None)
    if term_mgr is None:
        return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)

    # Terminated (failure, etc.) vs time_out (reached max length)
    # Use explicit None checks; do not use "tensor or fallback" (bool(tensor) is ambiguous for multi-element tensors)
    terminated = getattr(term_mgr, "terminated", None)
    if terminated is None:
        terminated = getattr(term_mgr, "computed_terminated", None)
    time_outs = getattr(term_mgr, "time_outs", None)
    if time_outs is None:
        time_outs = getattr(term_mgr, "computed_time_outs", None)
    if terminated is None or time_outs is None:
        # Fallback: use is_terminated style (all dones) and no scaling; still try to zero out time_out
        done = getattr(term_mgr, "dones", None)
        if done is None:
            return torch.zeros(env.num_envs, device=env.device, dtype=torch.float32)
        time_outs = getattr(term_mgr, "time_outs", torch.zeros_like(done, device=done.device))
        only_failure = done & (~time_outs)
        return -max_penalty * only_failure.float()
    only_failure = terminated & (~time_outs)

    # Episode length in steps (current step count for each env)
    episode_length_b = getattr(env, "episode_length_b", None)
    if episode_length_b is None:
        common = getattr(env, "common", None)
        episode_length_b = getattr(common, "episode_length_b", None) if common is not None else None
    if episode_length_b is None:
        scale = torch.ones(env.num_envs, device=env.device, dtype=torch.float32)
    else:
        max_steps = env.max_episode_length_s / env.step_dt
        scale = (episode_length_b.float().squeeze(-1) / float(max_steps)).clamp(0.0, 1.0)
    return -max_penalty * scale * only_failure.float()
