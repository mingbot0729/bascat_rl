# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# SPDX-License-Identifier: BSD-3-Clause

"""Custom event terms for domain randomization (e.g. terrain/floor friction)."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import torch

import isaaclab.utils.math as math_utils

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedEnv

logger = logging.getLogger(__name__)


def randomize_terrain_friction(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor | None,
    static_friction_range: tuple[float, float],
    dynamic_friction_range: tuple[float, float],
):
    """Randomize the terrain/floor physics material friction at startup.

    Samples static and dynamic friction from the given ranges and applies them to the
    terrain's physics material. The terrain is shared across envs, so one sample is
    applied to the whole floor. Uses the terrain's rigid body view if available.
    """
    terrain = env.scene.terrain
    if not hasattr(terrain, "root_physx_view") or terrain.root_physx_view is None:
        logger.debug(
            "randomize_terrain_friction: terrain has no root_physx_view, skipping floor friction randomization"
        )
        return
    try:
        # Sample one set of friction values (floor is shared)
        static = math_utils.sample_uniform(
            static_friction_range[0], static_friction_range[1], (1, 1), device="cpu"
        ).item()
        dynamic = math_utils.sample_uniform(
            dynamic_friction_range[0], dynamic_friction_range[1], (1, 1), device="cpu"
        ).item()
        dynamic = min(dynamic, static)  # PhysX: dynamic <= static
        # Get material buffer: (num_instances, num_shapes, 3) for [static_friction, dynamic_friction, restitution]
        materials = terrain.root_physx_view.get_material_properties()
        if materials is None or materials.numel() == 0:
            logger.debug("randomize_terrain_friction: no material buffer, skipping")
            return
        # Apply same friction to all terrain shapes (one shared floor)
        materials[:, :, 0] = static
        materials[:, :, 1] = dynamic
        # restitution unchanged
        all_ids = torch.arange(env.scene.num_envs, device="cpu") if env_ids is None else env_ids.cpu()
        terrain.root_physx_view.set_material_properties(materials, all_ids)
        logger.info(
            "randomize_terrain_friction: set floor friction static=%.2f dynamic=%.2f", static, dynamic
        )
    except Exception as e:
        logger.warning("randomize_terrain_friction failed (floor friction not randomized): %s", e)
