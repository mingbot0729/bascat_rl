# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""This sub-module contains the functions that are specific to the locomotion environments."""

from isaaclab.envs.mdp import *  # noqa: F401, F403

from .curriculums import *  # noqa: F401, F403
from .events import randomize_terrain_friction  # noqa: F401
from .rewards import *  # noqa: F401, F403
from .terminations import *  # noqa: F401, F403
from .amp_observations import amp_state_ostrich, AMP_OBS_DIM  # noqa: F401

# Explicitly export custom reward functions for clarity
from .rewards import (
    feet_air_time,
    feet_air_time_positive_biped,
    feet_air_time_positive_biped_with_standing,
    gait_alternating_phase,
    flat_posture_when_biped,
    base_pos_xy_drift_l2,
    left_right_joint_sym_l2,
    action_sym_l2,
    contact_switch_penalty,
    foot_contact_force_penalty,
    termination_penalty_scaled,
    feet_slide,
    track_lin_vel_xy_yaw_frame_exp,
    track_ang_vel_z_world_exp,
    base_height_low_penalty,
    base_height_target_exp,
    base_height_high_penalty,
    alive_posture_bonus,
    foot_slip_penalty,
)
